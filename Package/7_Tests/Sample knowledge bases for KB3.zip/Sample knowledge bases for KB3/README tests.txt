Unzip the "Sample knowledge bases.zip" file in a directory
of your choice (where you have read/write privileges).

You will have several ready to use simple knowledge bases both in French and in English.
Some of the KB have been translated automatically: in that case, the KB directory contains
the two sub-directories Francais and English.
The database "VisualFigaro samples.mdb" can be readily loaded in KB3: it contains all the 
knowledge bases and examples of small systems input with those knowledge bases.


D�-zippez le fichier "Sample knowledge bases.zip" dans un 
r�pertoire de votre choix (o� vous avez les droits de lecture/�criture).

Vous aurez ainsi plusieurs exemples de bases de connaissances simples
et pr�tes � l'emploi, en Fran�ais et en Anglais. 
Certaines base de connaissances ont �t� traduites automatiquement: dans ce cas, 
le r�pertoire de la base contient les deux sous-r�pertoires Francais et English.
La base de donn�es "VisualFigaro samples.mdb" peut �tre directement charg�e dans KB3 : elle contient
toutes les bases de connaissances et des exemples de petits syst�mes saisis avec ces bases de connaissances.