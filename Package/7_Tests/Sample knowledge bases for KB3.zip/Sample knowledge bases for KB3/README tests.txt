The directory "Sample knowledge bases for KB3" contains several ready to use simple knowledge bases both in French and in English.
Some of the KB have been translated automatically: in that case, the KB directory contains
the two sub-directories Francais and English.
The database "VisualFigaro samples.mdb" can be readily loaded in KB3: it contains all the 
knowledge bases and examples of small systems input with those knowledge bases.


Le r�pertoire "Sample knowledge bases for KB3" contient plusieurs bases de connaissances simples
et pr�tes � l'emploi, en Fran�ais et en Anglais. 
Certaines bases de connaissances ont �t� traduites automatiquement: dans ce cas, 
le r�pertoire de la base contient les deux sous-r�pertoires Francais et English.
La base de donn�es "VisualFigaro samples.mdb" peut �tre directement charg�e dans KB3 : elle contient
toutes les bases de connaissances et des exemples de petits syst�mes saisis avec ces bases de connaissances.