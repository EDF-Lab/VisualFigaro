Modif du 10 avril 2012 : 
Codage du fichier .fi en UTF8 (avec BOM, puisque maintenant le ST l'accepte)

Modif du 2 sept 2010 : 
Ajout d'un sous-menu "Statique"

Modif du 12 mars 2010 :
Actualisation du fichier bdcfr.xsd, v�rification du chargement dans 
les derni�res versions de VisualFigaro et KB3.

Modif du 21 f�vrier 2008 :
Passage des icones de .bmp en .ico.
V�rification du chargement dans VisualFigaro

Modif du 7 d�cembre 2006 :
MODIFICATION DE LA BDC DIAGFIA XML
1.	Mod�le de g�n�ration d�arbre renomm� (ajout des accents)
2.	Groupes de r�gles non modifiables pour les mod�les de g�n�ration ADD et de simulation
3.	Visualisations autoris�es non modifiables pour le mod�le de simulation
4.	Ajout de traitements externes
a.	FIGSEQ
b.	YAMS
5.	Visualisation des portes k/n : Ajout de la valeur de k en plus de la notion de � reli� �
6.	Diminution de la taille de l�ic�ne des portes k/n
7.	Suppression des r�gles de remplissage d�interfaces inutiles
8.	Mod�le de g�n�ration d�arbre : simplification des portes et suppression des boucles 
        non modifiables
MODIFICATION DE LA BDC DIAGFIA FIGARO
1.	Ajout de la facette EDITION NON MODIFIABLE pour l�interface � secouru � des blocs secours
2.	Suppression des contournements de bug mis en place en 2003

ATTENTION : 
R�cup�ration des �tudes : quand des ADD ont �t� g�n�r�s avec la pr�c�dente version de la BDC, 
on a perdu le groupe associ� � la g�n�ration d�arbre dans le param�trage � quand on r�g�n�re un ADD 
� partir des ADD existants, il faut choisir � nouveau le groupe sinon on obtient un arbre vide�
Le mieux est de r�g�n�rer les ADD en partant du mod�le BDC. 
--------------------------------------------------------------------------------------------------------
Modif du 6 oct 2004 : suppression dans le.bdc du champ date_modification, et ajout
du champ description contenant cette date. Ainsi on peut voir dans une BDD quelle version 
on utilise.
--------------------------------------------------------------------------------------------------------
Modifs du 29 avril 2004 : r�tablissement des accents, choix des bons groupes suivant
  traitement (suppression de l'objet syst�me "options").
--------------------------------------------------------------------------------------------------------
Modifs du 22 mai 2003 : enl�vement des accents dans le .bdc (la version avec accents 
est conserv�e dans un autre fichier)

EXPLICATION

Le serveur de traitement n'accepte pas les caract�res accentu�s dans les fichiers .bdc, alors qu'on pourrait �tre tent� d'en utiliser pour d�finir, par exemple, des mentions � afficher sur les objets lors d'une simulation interactive.
Dans les premi�res versions de KB3, il �tait possible d'avoir des caract�res accentu�s, et ils �taient correctement affich�s par l'IHM. Cela supposait de mettre en premi�re ligne du fichier .bdc la mention suivante :
<?xml version="1.0" encoding="UTF-8"?>
au lieu de la mention standard :
<?xml version="1.0" encoding="ISO-8859-1"?>

Pour l'instant, il faut donc �viter les caract�res accentu�s, mais apr�s modification du serveur de traitements on pourra � nouveau les utiliser.
Il faut prendre garde au fait que Textpad propose plusieurs formats pour la sauvegarde. Il faut choisir un format coh�rent avec l'en-t�te du fichier.
