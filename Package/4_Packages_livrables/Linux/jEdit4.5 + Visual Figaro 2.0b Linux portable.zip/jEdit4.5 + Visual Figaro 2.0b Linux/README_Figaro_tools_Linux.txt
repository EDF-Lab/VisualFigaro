Version of VisualFigaro: V2.0b

First use of VisualFigaro: 

  - Launch the editor Jedit by a double-click on Jedit.exe,
  - In Jedit, launch the VisualFigaro plugin via the plugin menu,
      and choose the option "dock left"

For your convenience, you will find KB3, examples of system models created with various knowledge bases, and the solver YAMS for KB3 models for download at the same place:
 http://sourceforge.net/projects/visualfigaro/files/


To work with VisualFigaro you will need to install separately at least the Figaro processor Figp.

Optionally, you may install: 
Fig0debug: powerful debugging tool for figaro0 models
(*) Figarbre: fault tree generator
(*) Tradbdc: translation French-English and English-French of knowledge bases and studies
YAMS: Monte Carlo simulator for processing figaro0 models

(*) not yet available under Linux

