Version of VisualFigaro: V2.0b

First use of VisualFigaro: 

  - Launch the editor Jedit by a double-click on Jedit.exe,
  - In Jedit, launch the VisualFigaro plugin via the plugin menu,
      and choose the option "dock left"

For your convenience, you will find KB3, examples of system models created with various knowledge bases, and the solver YAMS for KB3 models for download at the same place:
 http://sourceforge.net/projects/visualfigaro/files/
